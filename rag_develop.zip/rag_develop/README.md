## _Retrieval-Augmented Generation (RAG_ )

### Getting started

Setup environment, xem file [README.md](backend/README.md)
