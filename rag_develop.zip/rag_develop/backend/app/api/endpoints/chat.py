from fastapi import APIRouter, HTTPException, WebSocket, WebSocketDisconnect
from app.schemas.chat import ChatMessage, ChatResponse
from app.services.embedding_chat import process_chat_message

router = APIRouter()

@router.post("/chat", response_model=ChatResponse)
async def chat(message: ChatMessage):
    """
    Process a chat message and return a response
    """
    try:
        result = await process_chat_message(message.text)
        return ChatResponse(response=result[0], source_files=result[1])
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Error processing message: {str(e)}"
        )

@router.websocket("/chat")
async def websocket_chat(websocket: WebSocket):
    """
    Handle WebSocket chat connections
    """
    await websocket.accept()
    while True:
        try:
            # Nhận dữ liệu từ client
            received_text = await websocket.receive_text()
            message = ChatMessage.model_validate_json(received_text)
            
            # Xử lý câu hỏi và trả về câu trả lời kèm nguồn tài liệu
            answer, source_files = await process_chat_message(message.text)

            # Gửi lại câu trả lời
            response = ChatResponse(response=answer, source_files=source_files)
            await websocket.send_text(response.json())

        except WebSocketDisconnect:
            print("Client disconnected")
            break
        except Exception as e:
            # Gửi phản hồi lỗi cho client nếu có lỗi xảy ra
            error_response = ChatResponse(response=f"Error: {str(e)}", source_files=[])
            await websocket.send_text(error_response.json())
            break

