from fastapi import APIRouter, UploadFile, File, HTTPException
from typing import List
import os
from app.core.config import settings
from app.services.file_processor import process_file
from app.schemas.file import FileResponse, FileInfo
import aiofiles
import numpy as np
from datetime import datetime

router = APIRouter()

from sentence_transformers import SentenceTransformer
import numpy as np

# Load the pre-trained model
model = SentenceTransformer('all-MiniLM-L6-v2')

import faiss

# Khởi tạo FAISS index
dimension = 384  # Kích thước của vector
index = faiss.IndexFlatL2(dimension)

async def convert_text_to_vector(text: str) -> np.ndarray:
    embedding = model.encode(text)
    return np.array(embedding, dtype=np.float32)  

@router.post("/upload", response_model=FileResponse)
async def upload_file(file: UploadFile = File(...)):
    """
    Upload and process a document file (DOCX, XLSX, etc.)
    """
    # Validate file extension
    file_extension = file.filename.split(".")[-1].lower()
    if file_extension not in settings.ALLOWED_EXTENSIONS:
        raise HTTPException(
            status_code=400,
            detail=f"File type not allowed. Allowed types: {settings.ALLOWED_EXTENSIONS}"
        )
    
    # Create upload directory if it doesn't exist
    os.makedirs(settings.UPLOAD_DIR, exist_ok=True)
    
    # Save file
    file_path = os.path.join(settings.UPLOAD_DIR, file.filename)
    try:
        async with aiofiles.open(file_path, "wb") as buffer:
            content = await file.read()
            await buffer.write(content)
        
        # Process file and extract text
        extracted_text = await process_file(file_path, file_extension)
        
        # Save extracted text to a .txt file
        text_file_path = os.path.join(settings.UPLOAD_DIR, file.filename + ".txt")
        async with aiofiles.open(text_file_path, "w", encoding="utf-8") as text_file:
            await text_file.write(extracted_text)
        
        # Convert extracted_text to vector
        vector_data = await convert_text_to_vector(extracted_text)

        # Add vector into FAISS and update metadata
        from app.services.vector_store import add_to_vector_store  
        add_to_vector_store(vector_data, file.filename)

        # Optionally: Save vector data to file for backup
        vector_file_path = os.path.join(settings.UPLOAD_DIR, file.filename + ".vector")
        async with aiofiles.open(vector_file_path, "wb") as vector_file:
            await vector_file.write(vector_data.tobytes())  
        return FileResponse(
            filename=file.filename,
            content_type=file.content_type,
            text_content=extracted_text
        )

    except Exception as e:
        # Clean up uploaded files if error happens
        if os.path.exists(file_path):
            os.remove(file_path) 
        raise HTTPException(
            status_code=500,
            detail=f"Could not save file: {str(e)}"
        )

@router.get("/files", response_model=List[FileInfo])
async def list_files():
    """
    Get list of uploaded files
    """
    files = []
    try:
        for filename in os.listdir(settings.UPLOAD_DIR):
            if not filename.endswith(('.vector')):  # Skip processed files
                file_path = os.path.join(settings.UPLOAD_DIR, filename)
                if not os.path.exists(file_path + ".txt")  or not os.path.exists(file_path + ".vector"):
                    continue
                stats = os.stat(file_path)
                files.append(FileInfo(
                    filename=filename,
                    size=stats.st_size,
                    uploaded_at=datetime.fromtimestamp(stats.st_mtime)
                ))
        return sorted(files, key=lambda x: x.uploaded_at, reverse=True)
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Could not list files: {str(e)}"
        ) 