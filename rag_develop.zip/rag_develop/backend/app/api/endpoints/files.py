from fastapi import APIRouter, HTTPException, UploadFile, File
import os
from app.services.embedding_chat import process_file_upload

router = APIRouter()
UPLOAD_DIR = "uploads"

@router.post("/upload")
async def upload_file(file: UploadFile = File(...)):
    try:
        result = await process_file_upload(file)
        return {"status": "ok", "filename": result["filename"]}
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Error processing file: {str(e)}"
        )

@router.delete("/files/{filename}")
async def delete_file(filename: str):
    try:
        file_path = os.path.join(UPLOAD_DIR, filename)
        if not os.path.exists(file_path):
            raise HTTPException(
                status_code=404,
                detail=f"File {filename} not found"
            )
        os.remove(file_path)
        os.remove(file_path + ".txt")
        os.remove(file_path + ".vector")

        return {"message": f"File {filename} deleted successfully"}
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Error deleting file: {str(e)}"
        )
