import faiss
import os
import pickle
import numpy as np

FAISS_INDEX_PATH = 'faiss.index'
METADATA_PATH = 'metadata.pkl'

def load_faiss():
    if os.path.exists(FAISS_INDEX_PATH):
        return faiss.read_index(FAISS_INDEX_PATH)
    else:
        return faiss.IndexFlatL2(384)

def save_faiss(index):
    faiss.write_index(index, FAISS_INDEX_PATH)

def load_metadata():
    if os.path.exists(METADATA_PATH):
        with open(METADATA_PATH, 'rb') as f:
            return pickle.load(f)
    return []

def save_metadata(metadata):
    with open(METADATA_PATH, 'wb') as f:
        pickle.dump(metadata, f)

def add_to_vector_store(embedding: np.ndarray, filename: str):
    index = load_faiss()
    metadata = load_metadata()

    index.add(embedding.reshape(1, -1))
    save_faiss(index)

    metadata.append({"filename": filename})
    save_metadata(metadata)

#Lấy ra 3 file gần nhất với vector truy vấn
# Trả về danh sách tên file tương ứng với các vector gần nhất
def search_vector_store(query_embedding: np.ndarray, top_k=3) -> list[str]:
    index = load_faiss()
    metadata = load_metadata()

    if index.ntotal == 0 or len(metadata) == 0:
        return []

    D, I = index.search(query_embedding.reshape(1, -1), top_k)
    results = [metadata[i]['filename'] for i in I[0] if 0 <= i < len(metadata)]
    return results
