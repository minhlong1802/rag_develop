import google.generativeai as genai

# # Cấu hình API Key của bạn
# def configure_api():
#     genai.configure(api_key="AIzaSyCnUkk3mcPzixgUvRkLLztcKyNe1GMi6QE")

# Tạo đối tượng mô hình với cấu hình
def ask_gemini(prompt: str) -> str:
    genai.configure(api_key="AIzaSyCnUkk3mcPzixgUvRkLLztcKyNe1GMi6QE")
    # Cấu hình mô hình và các tham số
    generation_config = {
        "temperature": 0.9,
        "top_p": 1,
        "top_k": 1,
        "max_output_tokens": 4096,
    }

    safety_settings = [
        {
            "category": "HARM_CATEGORY_HARASSMENT",
            "threshold": "BLOCK_MEDIUM_AND_ABOVE"
        },
        {
            "category": "HARM_CATEGORY_HATE_SPEECH",
            "threshold": "BLOCK_MEDIUM_AND_ABOVE"
        },
        {
            "category": "HARM_CATEGORY_SEXUALLY_EXPLICIT",
            "threshold": "BLOCK_MEDIUM_AND_ABOVE"
        },
        {
            "category": "HARM_CATEGORY_DANGEROUS_CONTENT",
            "threshold": "BLOCK_MEDIUM_AND_ABOVE"
        }
    ]

    # Khởi tạo mô hình với tên và cấu hình
    model = genai.GenerativeModel(
        model_name="models/gemini-2.0-flash-001",
        generation_config=generation_config,
        safety_settings=safety_settings
    )

    # Tạo câu trả lời từ mô hình
    response = model.generate_content(prompt)

    content = response.text
    print(content) 
    return content
