from sentence_transformers import SentenceTransformer
import numpy as np

model = SentenceTransformer('sentence-transformers/all-MiniLM-L6-v2')

def get_embedding(text: str) -> np.ndarray:
    embedding = model.encode(text)
    return np.array(embedding, dtype=np.float32)
