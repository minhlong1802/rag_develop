from app.services.embedding import get_embedding
from app.services.vector_store import add_to_vector_store, search_vector_store
from app.services.llm import ask_gemini
from app.services.file_processor import save_uploaded_file, load_file_text

import os
import traceback

UPLOAD_DIR = "uploads"

def save_file(file_content: bytes, filename: str) -> str:
    os.makedirs(UPLOAD_DIR, exist_ok=True)
    file_path = os.path.join(UPLOAD_DIR, filename)
    with open(file_path, 'wb') as f:
        f.write(file_content)
    return file_path

def process_file_upload(file_content: bytes, filename: str) -> str:
    save_uploaded_file(file_content, filename)
    text = file_content.decode('utf-8', errors='ignore')
    embedding = get_embedding(text)
    add_to_vector_store(embedding, filename)
    return filename

async def process_chat_message(query: str) -> tuple[str, list[str]]:
    query_embedding = get_embedding(query)
    related_files = search_vector_store(query_embedding)

    if not related_files:
        return "Không tìm thấy tài liệu phù hợp.", []

    context = "\n".join([
        load_file_text(f) for f in related_files
    ])
    prompt = f"""Dựa trên nội dung tài liệu sau, hãy trả lời câu hỏi:

--- Tài liệu ---
{context}

--- Câu hỏi ---
{query}

Trả lời ngắn gọn và rõ ràng."""

    answer = ask_gemini(prompt)
    print(prompt)
    # Kết hợp tên file đã upload vào câu trả lời
    source_files = "\n".join(related_files)

    # Trả về câu trả lời và danh sách nguồn tài liệu
    return f"{answer}\n\nNguồn tham khảo: {source_files}", related_files